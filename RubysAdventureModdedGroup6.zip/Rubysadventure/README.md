# GaIMUnityTemplate
Standard template for Unity projects with some basic features (Unity gitignore, GitLFS, etc.)
To use this template, click the "Use this template" button at the top of the page to create a new repository on GitHub.  Then you can clone, pull, or otherwise use the repository as needed. If you are starting a new project, I'd suggest cloning this repository to your computer in your desired location, then creating your new Unity project in that folder.
